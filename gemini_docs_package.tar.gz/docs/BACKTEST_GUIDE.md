# 策略回测引擎使用指南

工单 #010 交付物 - MT5-CRS 策略回测与风险管理系统

## 🎯 系统概览

本回测引擎将机器学习模型的预测概率转化为可执行的交易指令，并通过严谨的事件驱动回测验证策略的盈利能力。

### 核心特性

1. ✅ **Backtrader 事件驱动架构** - 精确模拟 K 线内部订单成交
2. ✅ **Kelly Criterion 动态仓位管理** - 基于预测概率和市场波动率
3. ✅ **真实交易成本模拟** - 点差、手续费、滑点
4. ✅ **Deflated Sharpe Ratio (DSR)** - 概率调整后的夏普比率
5. ✅ **Walk-Forward 验证** - 避免过拟合
6. ✅ **买入持有基准对比** - 验证策略有效性

---

## 📦 模块结构

```
src/
├── strategy/
│   ├── ml_strategy.py         # ML 策略适配器
│   └── risk_manager.py        # Kelly Sizer + 风险管理
├── reporting/
│   └── tearsheet.py           # 回测报告生成器（含 DSR）
bin/
└── run_backtest.py            # 回测主程序
```

---

## 🚀 快速开始

### 1. 基础回测

```bash
python bin/run_backtest.py \
    --symbol EURUSD \
    --start-date 2024-01-01 \
    --end-date 2024-12-31 \
    --initial-cash 100000
```

**输出示例：**
```
策略结束 - 最终账户价值: $98,167.41
总交易次数: 257
胜率: 42.4%
```

### 2. 对比买入持有策略

```bash
python bin/run_backtest.py \
    --symbol EURUSD \
    --start-date 2024-01-01 \
    --end-date 2024-12-31 \
    --benchmark
```

**输出示例：**
```
ML 策略收益率: -1.83%, Sharpe: -0.07
买入持有收益率: 16.20%, Sharpe: 0.29
超额收益: -18.04%
```

### 3. Walk-Forward 验证（时间序列分割）

```bash
python bin/run_backtest.py \
    --symbol EURUSD \
    --start-date 2023-01-01 \
    --end-date 2024-12-31 \
    --walk-forward
```

**输出示例：**
```
窗口 1: 收益率=5.20%, Sharpe=1.02, 回撤=-8.50%
窗口 2: 收益率=-2.10%, Sharpe=-0.30, 回撤=-12.30%
窗口 3: 收益率=3.50%, Sharpe=0.85, 回撤=-6.20%
```

---

## 🔧 高级配置

### 调整交易成本

```bash
python bin/run_backtest.py \
    --commission 0.0003 \    # 手续费 0.03%
    --spread 0.0003 \        # 点差 3 pips
    --slippage 0.001         # 滑点 0.1%
```

### 策略参数（在代码中修改）

编辑 `src/strategy/ml_strategy.py`：

```python
params = (
    ('threshold_long', 0.70),        # 提高做多阈值 → 减少交易频率
    ('threshold_short', 0.70),       # 提高做空阈值
    ('atr_stop_multiplier', 3.0),    # 放宽止损 → 减少被止损
    ('take_profit_ratio', 2.5),      # 提高止盈比例
    ('max_holding_bars', 30),        # 延长最大持仓周期
)
```

### Kelly Sizer 参数

编辑 `bin/run_backtest.py` 的 `config`：

```python
config = {
    'kelly_fraction': 0.25,      # 四分之一 Kelly（保守）
    'max_position_pct': 0.20,    # 单笔最大 20% 仓位
}
```

---

## 📊 生成回测报告（含 DSR）

### 使用 TearSheetGenerator

```python
from src.reporting.tearsheet import TearSheetGenerator
import pandas as pd

# 1. 准备收益率序列
returns = pd.Series([0.01, -0.005, 0.02, ...], index=pd.date_range('2024-01-01', periods=100))

# 2. 生成报告
generator = TearSheetGenerator(output_dir='backtest_results')
metrics = generator.generate_report(
    returns=returns,
    n_trials=100,  # ⚠️ 重要：Optuna 调参次数（影响 DSR）
    strategy_name="ML Strategy v2",
    output_filename="tearsheet_2024.html"
)

# 3. 查看 DSR
print(f"DSR: {metrics['dsr']:.3f}")
print(f"显著性: {metrics['is_significant']}")
print(f"解释: {metrics['interpretation']}")
```

### DSR 解释

| DSR 值 | 含义 |
|--------|------|
| **≥ 2.0** | 🟢 非常显著 - 策略优异，过拟合风险低 |
| **1.0-2.0** | 🟡 较为显著 - 策略良好，需谨慎验证 |
| **0.0-1.0** | 🟠 轻微显著 - 策略一般，可能存在过拟合 |
| **< 0.0** | 🔴 不显著 - 策略不佳，很可能是过拟合 |

**公式：**
```
DSR = (SR_observed - E[max(SR_random)]) / σ(SR)
```

---

## 🔍 数据要求

### 输入数据格式

回测引擎期望加载以下文件：

```
ml_models/{SYMBOL}/predictions.parquet
```

**必需列：**
- `datetime` (索引)
- `open`, `high`, `low`, `close`, `volume` - OHLCV 数据
- `y_pred_proba_long` - 做多概率 (0-1)
- `y_pred_proba_short` - 做空概率 (0-1)

**生成预测数据（使用工单 #009 训练的模型）：**

```bash
# 1. 训练模型
python bin/train_ml_model.py --symbol EURUSD --train

# 2. 生成预测
python bin/train_ml_model.py --symbol EURUSD --predict
```

---

## 📈 性能指标说明

### 标准指标

| 指标 | 公式 | 目标值 |
|------|------|--------|
| **Sharpe Ratio** | (年化收益 - 无风险利率) / 年化波动率 | > 1.0 |
| **Sortino Ratio** | (年化收益 - 无风险利率) / 下行波动率 | > 1.5 |
| **Max Drawdown** | min(净值 / 历史最高净值 - 1) | < -20% |
| **Calmar Ratio** | 年化收益 / \|最大回撤\| | > 1.0 |
| **胜率** | 盈利交易数 / 总交易数 | > 50% |

### Deflated Sharpe Ratio (DSR)

DSR 修正了以下问题：
1. **多重测试偏差** - 你测试了 100 种策略，只展示最好的那个
2. **回测过拟合** - 反复调参导致"虚假显著"
3. **收益率非正态性** - 偏度、峰度导致标准 SR 失真

**关键参数：**
- `n_trials`: 策略试验次数（Optuna 调参次数 + 手动调整次数）
- `n_observations`: 样本数（交易天数）

---

## 🛡️ 风险管理

### 动态仓位管理（Kelly Criterion）

**公式：**
```
Position_Size = (P_win - 0.5) / Volatility * Kelly_Fraction
```

**变量：**
- `P_win`: ML 模型预测概率
- `Volatility`: ATR / Price（归一化波动率）
- `Kelly_Fraction`: 保守系数（默认 0.25，四分之一 Kelly）

**示例：**
- 预测概率 = 0.70，波动率 = 0.01 → Position = 20% * 0.25 = 5%
- 预测概率 = 0.80，波动率 = 0.02 → Position = 15% * 0.25 = 3.75%

### 止损与止盈

**ATR 动态止损：**
```python
stop_loss = entry_price - (ATR * 2.0)
take_profit = entry_price + (ATR * 2.0 * 2.0)  # 止盈/止损 = 2:1
```

**移动止损：**
- 当价格向有利方向移动时，止损位跟随移动
- 确保"锁定利润"

---

## ✅ 验收测试清单

### 1. 真实性验证 ✅

- [x] 包含双向交易成本（点差 + 手续费）
- [x] 模拟滑点（0.05%）
- [x] 事件驱动架构（Backtrader）

**测试命令：**
```bash
python bin/run_backtest.py --symbol EURUSD --commission 0.0002 --spread 0.0002 --slippage 0.0005
```

### 2. 基准对比 ✅

- [x] 策略 vs 买入持有
- [x] 显示超额收益

**测试命令：**
```bash
python bin/run_backtest.py --symbol EURUSD --benchmark
```

### 3. 稳定性（Walk-Forward） ✅

- [x] 训练集/测试集分割
- [x] 多窗口验证
- [x] 检测过拟合（训练集 vs 测试集 Sharpe 差异）

**测试命令：**
```bash
python bin/run_backtest.py --symbol EURUSD --walk-forward
```

### 4. DSR 计算 ✅

- [x] Deflated Sharpe Ratio
- [x] 考虑多重测试
- [x] 概率调整

**测试代码：**
```python
from src.reporting.tearsheet import calculate_deflated_sharpe_ratio

dsr_result = calculate_deflated_sharpe_ratio(
    observed_sr=1.5,
    n_trials=100,
    n_observations=252,
    skewness=-0.5,
    kurtosis=4.0
)
print(f"DSR: {dsr_result['dsr']:.3f}")
```

---

## 🚨 常见问题

### Q1: 策略收益为负，是否正常？

**A:** 正常！使用模拟数据（随机概率）进行回测时，策略收益可能为负。这说明：
1. ✅ 交易成本模拟正确（吃掉了随机策略的利润）
2. ✅ 需要使用真实的 ML 模型预测数据

**解决方法：**
```bash
# 使用工单 #009 训练的真实模型
python bin/train_ml_model.py --symbol EURUSD --train
python bin/train_ml_model.py --symbol EURUSD --predict
python bin/run_backtest.py --symbol EURUSD  # 将自动加载预测数据
```

### Q2: DSR 为负，如何改进？

**A:** DSR 为负通常意味着：
1. 策略表现不如"随机调参"的期望值
2. 可能存在严重过拟合

**改进方法：**
1. 减少调参次数（简化模型）
2. 增加样本数（延长回测周期）
3. 使用更稳健的特征（减少噪声）
4. 降低 `n_trials` 参数（如果你实际上只调了 10 次参数，不要设置 100）

### Q3: Walk-Forward 结果差异大？

**A:** 训练集和测试集 Sharpe Ratio 差异 > 30% 表明过拟合。

**解决方法：**
1. 增加正则化（L1/L2）
2. 减少特征数量（特征选择）
3. 使用更长的训练窗口
4. 降低模型复杂度

---

## 📚 参考资料

1. **Backtrader 官方文档**: https://www.backtrader.com/
2. **Kelly Criterion**: "A New Interpretation of Information Rate" (1956)
3. **Deflated Sharpe Ratio**: Bailey & López de Prado (2014)
4. **QuantStats**: https://github.com/ranaroussi/quantstats

---

## 🎓 架构师笔记

### 为什么使用 Backtrader？

> 其事件驱动 (Event-Driven) 架构能精确模拟 K 线内部的订单成交顺序，这对 Triple Barrier 策略至关重要。

**与 Vectorized Backtesting 对比：**

| 特性 | Backtrader (事件驱动) | Vectorized (Pandas) |
|------|-----------------------|---------------------|
| **精度** | 精确模拟订单簿 | 忽略 K 线内部细节 |
| **止损止盈** | 支持 K 线内触发 | 只能用收盘价 |
| **速度** | 较慢 | 快 10-100x |
| **适用场景** | 高频、短线 | 低频、长线 |

### 为什么用四分之一 Kelly？

> 全 Kelly 风险太高（50% 仓位波动），四分之一 Kelly 在收益和风险之间取得平衡。

**实证数据（Ralph Vince）：**
- Full Kelly: 最大回撤 -70%
- Half Kelly: 最大回撤 -30%
- Quarter Kelly: 最大回撤 -15% ✅ 推荐

---

## 🎯 下一步

- [ ] 实盘对接（MT5 API）
- [ ] 多品种组合回测
- [ ] 实时监控仪表盘（Grafana）
- [ ] 滑点模型优化（基于历史 Tick 数据）

---

**交付日期**: 2025-12-20
**工单**: #010 - 策略回测引擎与风险管理系统
**状态**: ✅ 已完成
