# 🚀 Cursor + Claude Code 快速启动指南

## 当前状态

✅ Python 智能提示正常
✅ 6 个推荐扩展可见
❌ Markdown 公式未渲染（扩展可能未激活）

---

## 🔥 立即修复（3 步骤）

### 第 1 步: 重启 Cursor 窗口

**操作**:
```
按 Ctrl+Shift+P
输入: reload
选择: Developer: Reload Window
```

**为什么**: 扩展安装后必须重启才能生效

---

### 第 2 步: 测试 Markdown 预览

**打开文件**:
```
docs/issues/这是一份为您精心准备的 工单 #010.5。.md
```

**按快捷键**: `Ctrl+Shift+V`

**检查效果**:
- ✅ Kelly 公式显示为分数符号（不是 `$$ ... $$` 纯文本）
- ✅ 🔥🚀 显示为彩色图标
- ✅ Python 代码有颜色高亮

---

### 第 3 步: 如果仍未生效

**检查扩展状态**:
```
1. 按 Ctrl+Shift+X 打开扩展面板
2. 搜索: markdown-preview-enhanced
3. 确认状态为 "已安装" 且 "已启用"
```

**如果显示 "已禁用"**:
- 点击 "启用" 按钮
- 再次重启窗口

---

## 📋 关键扩展清单（必装）

### Markdown 渲染（3 个）
```
✅ Markdown Preview Enhanced  (数学公式)
✅ Markdown All in One        (表格格式化)
✅ Markdown Emoji             (Emoji 显示)
```

### Python 开发（已安装）
```
✅ Python
✅ Pylance
```

---

## 🛠️ MCP 服务器配置（可选）

### 检查 Node.js

```bash
node --version
```

如果未安装:
```bash
sudo yum install nodejs npm
```

### 安装文件系统 MCP 服务器

```bash
npm install -g @modelcontextprotocol/server-filesystem
```

### 创建 MCP 配置

```bash
mkdir -p ~/.config/claude-code
cat > ~/.config/claude-code/mcp_config.json << 'EOF'
{
  "mcpServers": {
    "mt5-filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/opt/mt5-crs"]
    }
  }
}
EOF
```

### 重启 Claude Code

```bash
# 重启后配置生效
pkill -f claude-code
claude-code
```

---

## ✅ 验证成功标准

### Markdown 预览
- [ ] 公式显示为数学符号（分数形式）
- [ ] Emoji 显示为彩色图标
- [ ] 代码块有语法高亮

### Python 开发
- [x] 有智能提示（已确认）
- [x] 有类型检查（已确认）

### MCP 服务器（可选）
- [ ] Claude 可以直接访问项目文件
- [ ] 配置文件无报错

---

## 📞 需要帮助？

如果重启后仍然无法渲染，请告诉我：

1. 预览窗口的标题是什么？
2. 公式显示成什么样？（截图或描述）
3. 扩展面板中 "Markdown Preview Enhanced" 的状态？

---

**快速链接**:
- [完整配置指南](.vscode/CURSOR_QUICK_FIX.md)
- [MCP 配置详解](.vscode/mcp-config.md)
- [扩展检查清单](.vscode/EXTENSION_INSTALLATION_CHECKLIST.md)
