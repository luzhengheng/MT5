# 🚀 Gemini Pro 快速协同链接

> **最新更新**: 2025-12-20 - 工单 #010 完成 (策略回测引擎与风险管理系统)

---

## 📊 项目状态总览

| 工单 | 状态 | 完成度 | 代码量 | 说明 |
|------|------|--------|--------|------|
| **#008** | ✅ 完成 | 100% | 14,500+ 行 | 数据管线 + 75维特征工程 |
| **#009** | ✅ 完成 | 100% | 2,700+ 行 | 对冲基金级ML预测引擎 |
| **#010** | ✅ 完成 | 100% | 1,650+ 行 | 策略回测引擎与风险管理 |
| **#011** | ⏸️ 待开始 | 0% | - | 实盘交易系统 (MT5 API) |

**总代码量**: **18,850+ 行** (生产级质量)

---

## 🎯 工单 #010 核心成就 (新完成! 🔥)

### 12 大核心功能 ✅

1. **Backtrader 事件驱动回测** - 精确模拟 K 线内订单成交
2. **Kelly Criterion** - 基于预测概率的动态仓位管理
3. **Deflated Sharpe Ratio (DSR)** - 修正多重测试偏差
4. **Walk-Forward 验证** - 时间序列分割避免过拟合
5. **真实交易成本模拟** - 点差 + 手续费 + 滑点
6. **买入持有基准对比** - 验证策略有效性
7. **ATR 动态止损止盈** - 自适应风险管理
8. **移动止损** - 锁定利润
9. **账户级风险监控** - 熔断机制
10. **HTML 交互式报告** - 专业可视化
11. **累计收益曲线** - 直观展示策略表现
12. **月度收益热力图** - 识别季节性模式

### 技术架构

```
ML 模型预测
     ↓
┌──────────────────────────────┐
│   策略引擎 (MLStrategy)       │
│  ┌────────────────────────┐  │
│  │ 预测概率 > 0.65 → 信号 │  │
│  │ ATR 动态止损止盈       │  │
│  │ 移动止损锁定利润       │  │
│  └────────┬───────────────┘  │
└───────────┼──────────────────┘
            ↓
┌──────────────────────────────┐
│   风险管理 (KellySizer)       │
│  ┌────────────────────────┐  │
│  │ Kelly = (P-0.5)/σ      │  │
│  │ Position = Kelly * 0.25│  │
│  │ 最大仓位: 20%          │  │
│  └────────┬───────────────┘  │
└───────────┼──────────────────┘
            ↓
┌──────────────────────────────┐
│   Backtrader 回测引擎         │
│  ┌────────────────────────┐  │
│  │ 事件驱动执行           │  │
│  │ 真实成本模拟           │  │
│  │ K 线内订单触发         │  │
│  └────────┬───────────────┘  │
└───────────┼──────────────────┘
            ↓
┌──────────────────────────────┐
│   报告生成 (TearSheet)        │
│  ┌────────────────────────┐  │
│  │ Deflated Sharpe Ratio  │  │
│  │ HTML 交互式报告        │  │
│  │ 性能指标可视化         │  │
│  └────────────────────────┘  │
└──────────────────────────────┘
```

---

## 📁 核心文档 (优先阅读)

### 1. 工单 #010 完成报告 ⭐⭐⭐ (最新!)
**文件**: `docs/issues/ISSUE_010_COMPLETION_REPORT.md`

**内容**:
- ✅ 4 大模块详解 (策略/风险/回测/报告)
- 📊 1,650 行代码统计
- 🎓 4 大技术亮点 (Kelly/DSR/事件驱动/Walk-Forward)
- 📈 验收标准 (4/4 = 100% 通过)
- 🚀 完整使用示例

**建议**: **必读！** 这是了解回测系统的最佳入口

---

### 2. 回测引擎使用指南 ⭐⭐⭐ (最新!)
**文件**: `docs/BACKTEST_GUIDE.md`

**内容**:
- 🎯 系统概览与核心特性
- 🚀 3 种回测模式 (基础/基准对比/Walk-Forward)
- 🔧 高级配置 (交易成本/策略参数/Kelly Sizer)
- 📊 DSR 详细说明与解释
- 🛡️ 风险管理机制
- 🚨 常见问题与解决方案

**建议**: 想使用回测系统，必读此文档

---

### 3. 工单 #009 完成报告 ⭐⭐⭐
**文件**: `docs/issues/ISSUE_009_COMPLETION_REPORT.md`

**内容**:
- ✅ 8 大交付物详解
- 📊 2,700+ 行代码统计
- 🎓 5 大技术亮点 (Purged K-Fold/Ensemble Stacking 等)
- 📈 验收标准 (10/10 通过)

---

### 4. 机器学习高级训练指南 ⭐⭐
**文件**: `docs/ML_ADVANCED_GUIDE.md`

**内容**:
- 🎯 Purged K-Fold 详细原理
- 📐 Clustered Feature Importance 数学推导
- 🤖 Ensemble Stacking 架构详解

---

## 💻 关键代码文件 (Gemini 审查重点)

### 回测引擎 ⭐⭐⭐ (最新!)
**文件**: [bin/run_backtest.py](bin/run_backtest.py)
**代码量**: 400 行

**核心类**:
1. `BacktestRunner` - 回测执行器
2. `MLDataFeed` - 自定义数据源

**核心功能**:
```python
class BacktestRunner:
    def run_backtest(self, df, strategy_class=MLStrategy):
        cerebro = bt.Cerebro()
        cerebro.addstrategy(strategy_class)

        # 真实交易成本
        cerebro.broker.setcommission(commission=0.0002)
        cerebro.broker.set_slippage_perc(perc=0.0005)

        # Kelly Sizer
        cerebro.addsizer(KellySizer, kelly_fraction=0.25)

        return cerebro.run()

    def run_walkforward(self, df, train_months=6, test_months=2):
        # 时间序列分割
        for i in range(n_folds):
            test_df = df.loc[test_start:test_end]
            cerebro, strat = self.run_backtest(test_df)
```

**审查重点**:
- [ ] Walk-Forward 分割逻辑是否正确?
- [ ] 数据加载是否处理缺失值?
- [ ] 错误处理是否完善?

---

### ML 策略适配器 ⭐⭐⭐ (最新!)
**文件**: [src/strategy/ml_strategy.py](src/strategy/ml_strategy.py)
**代码量**: 260 行

**核心类**:
1. `MLStrategy` - ML 驱动的交易策略
2. `BuyAndHoldStrategy` - 买入持有基准

**核心逻辑**:
```python
class MLStrategy(bt.Strategy):
    params = (
        ('threshold_long', 0.65),       # 做多阈值
        ('atr_stop_multiplier', 2.0),   # 止损倍数
        ('take_profit_ratio', 2.0),     # 止盈/止损比率
        ('enable_trailing_stop', True), # 移动止损
    )

    def next(self):
        # 信号检测
        if self.position:
            # 出场逻辑：止损/止盈/最大持仓周期
            if current_price <= self.stop_loss:
                self.close()
        else:
            # 入场逻辑：预测概率 > 阈值
            if y_pred_long > self.params.threshold_long:
                self.buy()
```

**审查重点**:
- [ ] 止损止盈逻辑是否存在边界条件 bug?
- [ ] 移动止损实现是否正确?
- [ ] 多空切换是否会出现问题?

---

### 风险管理器 ⭐⭐⭐ (最新!)
**文件**: [src/strategy/risk_manager.py](src/strategy/risk_manager.py)
**代码量**: 330 行

**核心类**:
1. `KellySizer` - Kelly Criterion 仓位管理
2. `DynamicRiskManager` - 账户级风险监控

**Kelly 公式实现**:
```python
class KellySizer(bt.Sizer):
    def _getsizing(self, comminfo, cash, data, isbuy):
        # 获取预测概率
        p_win = data.y_pred_proba_long[0]

        # 计算波动率 (ATR)
        atr_value = self.strategy.atr[0]
        normalized_volatility = atr_value / current_price

        # Kelly 公式变体
        kelly_pct = (p_win - 0.5) / normalized_volatility
        kelly_pct = kelly_pct * 0.25  # 四分之一 Kelly

        # 限制范围 [1%, 20%]
        kelly_pct = max(0.01, min(kelly_pct, 0.20))

        return int(account_value * kelly_pct / current_price)
```

**审查重点**:
- [ ] Kelly 公式实现是否正确?
- [ ] 波动率归一化是否合理?
- [ ] 四分之一 Kelly 是否过于保守?
- [ ] 是否需要加入 Optimal F?

---

### 报告生成器 ⭐⭐⭐ (最新!)
**文件**: [src/reporting/tearsheet.py](src/reporting/tearsheet.py)
**代码量**: 460 行

**核心功能**:
1. **Deflated Sharpe Ratio 计算**
2. HTML 交互式报告生成
3. 累计收益曲线、回撤分析、月度热力图

**DSR 公式实现**:
```python
def calculate_deflated_sharpe_ratio(
    observed_sr, n_trials, n_observations, skewness, kurtosis
):
    # 1. 期望最大 SR (基于极值理论)
    expected_max_sr = sqrt(2*log(n_trials)) - ...

    # 2. SR 标准差 (考虑非正态性)
    sr_variance = (
        1.0 - skewness * observed_sr
        + ((kurtosis - 3.0) / 4.0) * (observed_sr ** 2)
    ) / n_observations

    # 3. Deflated SR
    dsr = (observed_sr - expected_max_sr) / sqrt(sr_variance)

    # 4. p-value
    dsr_pvalue = 1.0 - stats.norm.cdf(dsr)

    return dsr
```

**审查重点**:
- [ ] DSR 公式实现是否正确?
- [ ] 极值期望公式是否有更精确的版本?
- [ ] 非正态性调整是否充分?
- [ ] 是否需要 Bootstrap 验证?

---

### 验证器模块 ⭐⭐⭐
**文件**: [src/models/validation.py](src/models/validation.py)
**代码量**: 297 行

**核心功能**:
```python
class PurgedKFold:
    """防止信息泄漏的交叉验证器"""

    def _purge_train_set(self, train_idx, test_idx, event_ends):
        # 删除训练集中与测试集标签重叠的样本
        test_start = event_ends.iloc[test_idx].min()
        overlap_mask = train_event_ends >= test_start
        return train_idx[~overlap_mask]
```

**审查重点**:
- [ ] Purging 逻辑是否正确?
- [ ] Embargoing 比例 (1%) 是否合理?

---

### 训练器模块 ⭐⭐⭐
**文件**: [src/models/trainer.py](src/models/trainer.py)
**代码量**: 896 行

**核心类**:
1. `LightGBMTrainer`
2. `CatBoostTrainer`
3. `EnsembleStacker`
4. `OptunaOptimizer`

**审查重点**:
- [ ] Ensemble Stacking 实现是否正确?
- [ ] Out-of-Fold 预测是否防止信息泄漏?

---

## 🎯 Gemini Pro 可以帮助的 3 件事

### 1. 回测系统代码审查 ⭐⭐⭐ (最需要! 🔥)

**重点审查**:
- **Kelly Criterion 实现** - 公式是否正确? 波动率归一化是否合理?
- **Deflated Sharpe Ratio** - 极值理论公式是否精确?
- **Walk-Forward 逻辑** - 时间分割是否存在前视偏差?
- **止损止盈逻辑** - 是否存在边界条件 bug?

**核心问题**:
1. Kelly 公式中使用 `(P_win - 0.5) / Volatility`，分母应该是 ATR 还是收益率标准差?
2. DSR 的期望最大 SR 公式是否有更精确的版本 (考虑相关性)?
3. 移动止损实现是否会导致过度交易?
4. 四分之一 Kelly 是否过于保守? 能否动态调整?

---

### 2. 性能优化建议 ⭐⭐

**当前问题**:
1. 回测速度: ~500 bars/秒 (是否需要优化?)
2. Walk-Forward 需要多次回测 (能否并行化?)
3. DSR 计算涉及高级统计 (能否优化?)

**期望建议**:
- 给出回测引擎加速方案 (Numba/Cython/多进程)
- Walk-Forward 并行化架构设计
- 大数据集回测优化策略

---

### 3. 工单 #011 规划建议 ⭐⭐

**下一步**: 实盘交易系统 (MT5 API 对接)

**核心问题**:
1. 如何将回测策略无缝迁移到实盘?
2. 实盘风险管理需要哪些额外机制?
3. 如何监控模型漂移 (Model Drift)?
4. 如何处理断线重连、订单失败等异常?
5. 如何实现多品种、多策略并行交易?

**期望输出**:
- 实盘交易系统架构设计
- MT5 API 集成方案
- 关键组件清单与优先级

---

## 📊 项目统计

| 指标 | 数值 |
|------|------|
| **总代码量** | 18,850+ 行 |
| **工单完成** | 3/5 (60%) |
| **特征维度** | 75 维 |
| **回测功能** | 12 项 |
| **验证策略** | Purged K-Fold / Walk-Forward |
| **风险管理** | Kelly Criterion + 熔断机制 |
| **性能指标** | 10+ 个 (Sharpe, DSR, Calmar 等) |

---

## 🚀 快速测试

### 回测系统测试

```bash
# 1. 基础回测
python bin/run_backtest.py --symbol EURUSD --start-date 2024-01-01 --end-date 2024-12-31

# 2. 基准对比
python bin/run_backtest.py --symbol EURUSD --benchmark

# 3. Walk-Forward 验证
python bin/run_backtest.py --symbol EURUSD --walk-forward

# 4. 自定义交易成本
python bin/run_backtest.py --commission 0.0003 --spread 0.0003 --slippage 0.001

# 5. 查看结果
ls backtest_results/
```

### 完整流程测试

```bash
# 1. 生成示例数据
python bin/generate_sample_data.py

# 2. 训练 ML 模型
python bin/train_ml_model.py

# 3. 生成预测
python bin/train_ml_model.py --predict

# 4. 运行回测
python bin/run_backtest.py --symbol EURUSD
```

---

## 📖 理论基础

### 必读书籍
1. **《Advances in Financial Machine Learning》** - Marcos Lopez de Prado
   - Chapter 7: Cross-Validation in Finance (Purged K-Fold)
   - Chapter 8: Feature Importance (MDA, Clustered Importance)
   - Chapter 10: Bet Sizing (Kelly Criterion)
   - Chapter 11: The Dangers of Backtesting (Deflated Sharpe Ratio)

2. **《Quantitative Trading》** - Ernest P. Chan
   - Chapter 6: Backtesting Strategies
   - Chapter 7: Automated Trading Systems

### 论文参考
1. **Deflated Sharpe Ratio**: Bailey & López de Prado (2014)
2. **Kelly Criterion**: Kelly (1956)
3. **Purged K-Fold**: López de Prado (2018)

---

## 💬 协同工作流

1. **Gemini 阅读** 📖
   - 优先阅读: ISSUE_010_COMPLETION_REPORT.md
   - 深入理解: BACKTEST_GUIDE.md
   - 代码审查: run_backtest.py, ml_strategy.py, risk_manager.py, tearsheet.py

2. **Gemini 反馈** 💬
   - 指出潜在 bug (特别是 Kelly/DSR 公式)
   - 提供性能优化建议
   - 给出工单 #011 规划思路

3. **Claude 实施** ⚡
   - 根据 Gemini 建议修改代码
   - 优化回测性能
   - 准备实盘系统开发

4. **迭代优化** 🔄
   - Gemini 审查修改后的代码
   - 继续优化直到满意
   - 进入工单 #011

---

## 📞 联系方式

**GitHub 仓库**: https://github.com/luzhengheng/MT5

如有问题，请在 GitHub Issues 中提出:
- 代码 bug: [Issues](https://github.com/luzhengheng/MT5/issues)
- 功能建议: [Discussions](https://github.com/luzhengheng/MT5/discussions)

---

**最后更新**: 2025-12-20 04:50 (UTC+8)
**更新人**: Claude Sonnet 4.5
**协同状态**: 等待 Gemini Pro 审查工单 #010 ⏳
**当前进度**: 3/5 工单完成 (60%)
